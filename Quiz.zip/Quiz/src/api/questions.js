var quizQuestions = [
  {
    question: " Which beach has become the first in India to have Wi-Fi connectivity?",
    answerindex : 1,
    answers: [
      {
        content: "Malpe beach",
        answer : false
      },
      {
        content: "Karwar beach",
        answer : false
      },
      {
        content: "Kumta beach",
        answer : false
      },
      {
        content: "Trasi beach",
        answer : false
      }
    ]
  },
  {
    question: "In terms of area Karnataka is the ____________ largest State in India?",
    answerindex : 3,
    answers: [
      {
        content: "Fifth",
        answer : false
      },
      {
        content: "Sixth",
        answer : false
      },
      {
        content: "Seventh",
        answer : false
      },
      {
        content: "Eighth",
        answer : false
      }
    ]
  },
  {
    question: "In which city is the Central Institute of Indian Languages located?",
    answerindex : 1,
    answers: [
      {
        content: "Mysuru",
        answer : false
      },
      {
        content: "Bengaluru",
        answer : false
      },
      {
        content: "Dharwad",
        answer : false
      },
      {
        content: "Udupi",
        answer : false
      }
    ]
  },
  {
    question: "Who killed Bhaubali",
    answerindex : 4,
    answers: [
      {
        content: "Vasanth",
        answer : false
      },
      {
        content: "Vignesh",
        answer : false
      },
      {
 
        content: "Vishwa",
        answer : false
      },
      {

        content: "Katappa",
        answer : false
      }
    ]
  },
  {
    question: "The port Mangalore is located in which district of Karnataka?",
    answerindex : 2,
    answers: [
      {

        content: "Udupi",
        answer : false
      },
      {
 
        content: "Dakshina Kannada",
        answer : false
      },
      {

        content: "Hassan",
        answer : false
      },
      {

        content: "Uttara Kannada",
        answer : false
      }
    ]
  }
];

export default quizQuestions;